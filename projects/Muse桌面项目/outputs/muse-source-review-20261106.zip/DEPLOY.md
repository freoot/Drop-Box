# Deploy Runbook — mxyai88.com + ativ.cc (Cloudflare Pages)

Status of the domains (checked 2026-11-04):
- `mxyai88.com` serves the default **Cloudflare registrar placeholder**
  ("Welcome to Cloudflare"). The domain is already in a Cloudflare
  account; deploying over the placeholder is safe.
- `ativ.cc` does not resolve yet. If it is not in the same Cloudflare
  account, add the zone first (registrar nameserver change) or follow
  the custom-domain wizard, which explains the DNS step.

The deployable folders are the `dist/` outputs of each site
(rebuild first, then run the checks):

```bash
cd ~/Desktop/valthra-shared/muse/code/mxyai88 && python3 build.py   # 72 routes + 404
cd ~/Desktop/valthra-shared/muse/code/ativ    && python3 build.py   # 19 routes + 404
cd ~/Desktop/valthra-shared/muse/code         && python3 tests/run_all.py
```

## Per site (repeat twice)

1. Cloudflare dashboard → Workers & Pages → Create → Pages →
   **Upload assets** (direct upload; no Git, no build command).
2. Project name: `mxyai88` / `ativ`.
3. Upload the **contents of that site's `dist/`** (the folder itself
   becomes the site root: `index.html`, `404.html`, `assets/`, …).
4. After the first deploy succeeds on `*.pages.dev`, open the project →
   Custom domains → Set up a custom domain → `mxyai88.com` (and `www`
   if wanted) / `ativ.cc`. Because the zone is on Cloudflare, the
   wizard adds the DNS record itself; wait for the certificate to go
   active (usually minutes).
5. No environment variables, no build settings, no functions are used.

## Post-deploy verification (do not skip)

```bash
curl -sI https://mxyai88.com/ | head -1                 # expect 200
curl -sI https://mxyai88.com/tool/jasper/ | head -1     # expect 200
curl -sI https://mxyai88.com/no-such-page | head -1     # expect 404
curl -s  https://mxyai88.com/no-such-page | grep -o "That page is not in the directory"
curl -s  https://mxyai88.com/sitemap.xml | head -3
curl -s  https://mxyai88.com/robots.txt
# same six for https://ativ.cc (404 grep text: "That page is not on the shelf",
# article spot-check path: /blog/best-ai-writing-tools-for-creators/)
```

Then in a browser: open the home page, run one search that returns
nothing (empty state + Clear button), tab through the nav (visible
focus), open one article on ATIV and click a "Visit … (official site)"
button, and check one page on a phone-width viewport.

## Rollback

Pages keeps every deployment: project → Deployments → pick the
previous one → Rollback. Nothing in this setup writes to the domain's
email or other services.

## Still owner-gated after launch (see each LAUNCH-STATUS.md)

- Create `submit@` / `featured@mxyai88.com` mailboxes (or supply a form
  endpoint) so the mailto forms land somewhere real.
- Confirm Featured planned pricing before opening the program.
- ATIV: publish a contact email if reader corrections are wanted;
  re-check the 30 tools' prices against live vendor pages.
- Legal review of Privacy/Terms drafts.
