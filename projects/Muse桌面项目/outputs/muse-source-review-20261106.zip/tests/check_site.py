#!/usr/bin/env python3
"""Static checks for a built dist/ tree: internal links, anchors, metadata.
Usage: python3 check_site.py <dist_dir> <base_url>
Exit code 0 = all checks pass. Prints a JSON report to stdout."""
import json, re, sys
from pathlib import Path

dist = Path(sys.argv[1]).resolve()
base = sys.argv[2].rstrip("/")
html_files = sorted(dist.rglob("*.html"))
problems, pages = [], []
ids_by_file = {}
hrefs = []
for f in html_files:
    text = f.read_text(encoding="utf-8", errors="replace")
    rel = "/" + str(f.relative_to(dist))
    ids_by_file[rel] = set(re.findall(r'id="([^"]+)"', text))
    pages.append(rel)
    for m in re.finditer(r'(?:href|src)="([^"]+)"', text):
        hrefs.append((rel, m.group(1)))
    # metadata checks
    if "<title>" not in text:
        problems.append(f"{rel}: missing <title>")
    if 'rel="canonical"' not in text:
        problems.append(f"{rel}: missing canonical")
    if 'name="description"' not in text:
        problems.append(f"{rel}: missing meta description")
    if 'property="og:title"' not in text:
        problems.append(f"{rel}: missing og:title")

def target_exists(path):
    p = dist / path.lstrip("/")
    if path.endswith("/") or path == "/":
        return (p / "index.html").is_file()
    return p.is_file()

for src, url in hrefs:
    if url.startswith(("http://", "https://", "mailto:", "tel:", "data:")):
        continue
    if url.startswith("#"):
        frag = url[1:]
        if frag and frag not in ids_by_file.get(src, set()):
            problems.append(f"{src}: fragment #{frag} has no matching id on same page")
        continue
    path, _, frag = url.partition("#")
    if path and not target_exists(path):
        problems.append(f"{src}: broken internal link {url}")
        continue
    if frag:
        t = path if path else src
        trel = t if t.endswith(".html") else (t.rstrip("/") + "/index.html")
        if frag not in ids_by_file.get(trel, set()):
            problems.append(f"{src}: fragment #{frag} not found in {t}")

# sitemap vs pages
sm = dist / "sitemap.xml"
if sm.is_file():
    urls = re.findall(r"<loc>([^<]+)</loc>", sm.read_text(encoding="utf-8"))
    sm_paths = {u[len(base):] or "/" for u in urls}
    page_paths = {p[:-len("index.html")] if p.endswith("index.html") else p for p in pages}
    for p in sorted(page_paths - sm_paths):
        if p != "/404.html":
            problems.append(f"sitemap: page {p} not in sitemap")
    for p in sorted(sm_paths - page_paths):
        problems.append(f"sitemap: {p} in sitemap but no page built")
else:
    problems.append("sitemap.xml missing")
if not (dist / "robots.txt").is_file():
    problems.append("robots.txt missing")

print(json.dumps({"dist": str(dist), "pages": len(pages),
                  "links_checked": len(hrefs), "problems": problems}, indent=1))
sys.exit(1 if problems else 0)
