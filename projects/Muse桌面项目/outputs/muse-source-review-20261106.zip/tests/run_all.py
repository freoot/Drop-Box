#!/usr/bin/env python3
"""Full pre-launch check for both sites.

For each site: copy sources to a temp tree with NO brand/video assets
(the hard case), build, then verify the output:
  - build exits 0
  - internal links / anchors / metadata / sitemap pass (check_site.py)
  - dist/404.html exists
  - no forbidden placeholder or false-claim patterns in any HTML:
    dead '#' links, affiliate TODO markers, TODO comments,
    commission claims that do not match the sites' disclosed state.

Usage: python3 run_all.py
Exit code 0 = everything passes.
"""
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
CODE = HERE.parent
SITES = [("mxyai88", "https://mxyai88.com"), ("ativ", "https://ativ.cc")]
FORBIDDEN = [
    'href="#"',
    "mailto:",
    "data-affiliate",
    "<!-- TODO",
    "TODO:",
    "may earn a commission",
    "We may earn a commission",
    "placeholder pricing",
    "Introductory placeholder",
]

failures = []


def run(cmd, cwd=None):
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)


for site, base in SITES:
    print(f"\n===== {site} =====")
    with tempfile.TemporaryDirectory() as td:
        root = Path(td) / "muse"
        dst = root / "code" / site
        shutil.copytree(
            CODE / site, dst,
            ignore=shutil.ignore_patterns("dist", "__pycache__", "og-src"),
        )
        # no-asset environment: empty brand/video dirs
        (root / "images" / site).mkdir(parents=True)
        (root / "videos" / site).mkdir(parents=True)

        b = run([sys.executable, "build.py"], cwd=dst)
        if b.returncode != 0:
            failures.append(f"{site}: build failed\n{b.stdout}\n{b.stderr}")
            print("BUILD FAILED")
            print(b.stdout[-800:], b.stderr[-800:])
            continue
        print("build ok")

        dist = dst / "dist"
        c = run([sys.executable, str(HERE / "check_site.py"), str(dist), base])
        report = json.loads(c.stdout)
        if c.returncode != 0:
            failures.append(f"{site}: check_site problems: {report['problems']}")
        print(f"check_site: {report['pages']} pages, "
              f"{report['links_checked']} links, {len(report['problems'])} problems")

        if not (dist / "404.html").is_file():
            failures.append(f"{site}: dist/404.html missing")
        else:
            print("404.html present")

        bad = []
        for html in dist.rglob("*.html"):
            text = html.read_text(encoding="utf-8", errors="replace")
            for pat in FORBIDDEN:
                if pat in text:
                    bad.append(f"{html.relative_to(dist)}: contains {pat!r}")
        if bad:
            failures.append(f"{site}: forbidden patterns:\n" + "\n".join(bad))
        else:
            print("no forbidden placeholder/false-claim patterns")

        if site == "mxyai88":
            # Regression guard for the 2026-11-06 counter bug: the home
            # filter JS counted every [data-search] card on the page
            # (Editor's picks + Latest included -> 63 instead of 50) and
            # hid those sections while searching. The filter must be
            # scoped to the main listing grid (#toolGrid) only.
            tools_data = json.loads(
                (CODE / site / "data" / "tools.json").read_text(encoding="utf-8"))
            n_tools = len(tools_data)

            def in_scope(html_text):
                a = html_text.find('id="toolGrid"')
                b = html_text.find('id="noresults"')
                if a == -1 or b == -1 or b < a:
                    return -1
                return html_text[a:b].count("data-search=")

            home = (dist / "index.html").read_text(encoding="utf-8")
            scope_errs = []
            if "querySelectorAll('[data-search]')" in home:
                scope_errs.append("filter JS uses the unscoped [data-search] selector")
            if "#toolGrid [data-search]" not in home:
                scope_errs.append("filter JS is not scoped to #toolGrid")
            hs = in_scope(home)
            total_cards = home.count("data-search=")
            if hs != n_tools:
                scope_errs.append(
                    f"home #toolGrid holds {hs} cards, expected {n_tools}")
            if not total_cards > hs:
                scope_errs.append(
                    "no cards outside #toolGrid on home (picks/latest missing?)")
            # one category page: in-scope count must equal its tool count
            slug = tools_data[0]["categories"][0]
            expect = sum(1 for t in tools_data if t["categories"][0] == slug)
            cat = (dist / "category" / slug / "index.html").read_text(encoding="utf-8")
            cs = in_scope(cat)
            if cs != expect:
                scope_errs.append(
                    f"category {slug} #toolGrid holds {cs} cards, expected {expect}")
            if scope_errs:
                failures.append("mxyai88: filter scope: " + "; ".join(scope_errs))
            else:
                print(f"filter scope ok: home grid {hs} of {total_cards} cards "
                      f"in scope; category {slug} {cs}")

print("\n===== RESULT =====")
if failures:
    for f in failures:
        print("FAIL:", f)
    sys.exit(1)
print("ALL CHECKS PASS")
