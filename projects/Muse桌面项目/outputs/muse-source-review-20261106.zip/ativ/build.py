#!/usr/bin/env python3
"""ATIV (ativ.cc) — dependency-free static site generator.

Reads structured content from content/ and writes a complete static site
to dist/, ready for Cloudflare Pages (publish directory: dist).

Usage: python3 build.py
"""
import html
import json
import re
import shutil
import struct
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CONTENT = ROOT / "content"
DIST = ROOT / "dist"
BASE = "https://ativ.cc"
DISCLOSURE = ("ATIV currently uses no affiliate links: buttons go to the vendors’ official "
              "sites and we earn nothing if you buy. Rankings are editorial either way.")
YEAR = "2026"

CATEGORIES = {
    "writing": ("Writing", "Drafts, scripts, newsletters, and the tools that help you ship words every week."),
    "video": ("Video", "Short-form editing, captions, and repurposing tools for people who publish on camera."),
    "design": ("Design", "Image generation and design tools that respect a small budget."),
    "productivity": ("Productivity", "Notes, tasks, and focus tools for solopreneurs and small teams."),
    "automation": ("Automation", "Connect the apps you already use and delete the busywork between them."),
}

LOGO_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 148 40" role="img" aria-label="ATIV">
  <rect x="1" y="1" width="38" height="38" rx="7" fill="#A83C26"/>
  <path d="M20 9 L31 31 H25.6 L23.4 26.2 H16.6 L14.4 31 H9 Z M20 17.4 L18.6 21 H21.4 Z" fill="#FBF6EE"/>
  <rect x="27.5" y="27.5" width="5" height="5" fill="#D9A441"/>
  <text x="48" y="28" font-family="Georgia, 'Times New Roman', serif" font-size="24" font-weight="700" letter-spacing="3" fill="#221D18">ATIV</text>
</svg>
"""

CSS = """
:root{
  --brick:#A83C26; --brick-dark:#8C2F1D; --mustard:#D9A441; --cream:#FBF6EE;
  --paper:#FFFDF8; --ink:#221D18; --muted:#6E6257; --line:#E5DCCB;
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
a:focus-visible,button:focus-visible{outline:3px solid var(--mustard);outline-offset:2px}
.skip{position:absolute;left:-9999px;top:0;background:var(--brick);color:#fff;padding:10px 16px;z-index:60;font-weight:600}
.skip:focus{left:8px;top:8px;color:#fff}
body{margin:0;background:var(--cream);color:var(--ink);
  font-family:'Inter',-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;
  font-size:17px;line-height:1.65;-webkit-font-smoothing:antialiased}
h1,h2,h3,.serif{font-family:'Newsreader',Georgia,'Times New Roman',serif;line-height:1.2}
a{color:var(--brick);text-decoration-thickness:1px;text-underline-offset:3px}
a:hover{color:var(--brick-dark)}
img,svg{max-width:100%}
.wrap{max-width:1060px;margin:0 auto;padding:0 20px}
.narrow{max-width:760px}
/* header */
.site-header{background:var(--cream);border-bottom:2px solid var(--ink);position:sticky;top:0;z-index:20}
.header-in{display:flex;align-items:center;gap:28px;padding:12px 0;flex-wrap:wrap}
.logo{display:inline-flex;align-items:center;text-decoration:none}
.logo svg{height:38px;width:auto;display:block}
.main-nav{display:flex;gap:22px;flex-wrap:wrap;margin-left:auto}
.main-nav a{color:var(--ink);text-decoration:none;font-weight:600;font-size:15px}
.main-nav a:hover{color:var(--brick)}
/* hero */
.hero{padding:56px 0 40px;border-bottom:1px solid var(--line)}
.kicker{font-size:13px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--brick)}
.small{font-size:.85rem;color:var(--muted)}
.hero h1{font-size:clamp(34px,5.4vw,54px);margin:12px 0 14px;font-weight:600;max-width:16em}
.hero p.lede{font-size:20px;color:#463B31;max-width:38em;margin:0 0 22px}
.rule{width:64px;height:5px;background:var(--mustard);border:none;margin:26px 0}
/* layout bits */
.section{padding:40px 0}
.section h2{font-size:30px;margin:0 0 8px}
.section .sub{color:var(--muted);margin:0 0 24px;max-width:44em}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:18px}
.card{background:var(--paper);border:1px solid var(--line);border-radius:10px;padding:20px;display:flex;flex-direction:column;gap:8px}
.card:hover{border-color:var(--mustard)}
.card .cat{font-size:12px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--brick)}
.card h3{margin:0;font-size:21px}
.card h3 a{color:var(--ink);text-decoration:none}
.card h3 a:hover{color:var(--brick)}
.card p{margin:0;color:#4c4136;font-size:15.5px;flex:1}
.card .meta{font-size:13.5px;color:var(--muted)}
.cat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:14px}
.cat-card{background:var(--paper);border:1px solid var(--line);border-left:5px solid var(--brick);border-radius:8px;padding:16px;text-decoration:none;color:var(--ink)}
.cat-card:hover{border-left-color:var(--mustard)}
.cat-card strong{display:block;font-family:'Newsreader',Georgia,serif;font-size:20px}
.cat-card span{font-size:14px;color:var(--muted)}
/* article */
.article-head{padding:44px 0 8px}
.article-head h1{font-size:clamp(30px,4.6vw,44px);margin:10px 0 12px;font-weight:600}
.byline{color:var(--muted);font-size:14.5px;display:flex;gap:14px;flex-wrap:wrap}
.disclosure-box{background:#F4E9D4;border:1px solid var(--mustard);border-radius:8px;
  padding:12px 16px;font-size:14.5px;margin:22px 0}
article p{margin:0 0 18px}
article h2{font-size:27px;margin:36px 0 12px}
article h3{font-size:21px;margin:24px 0 8px}
/* tables */
.table-scroll{overflow-x:auto;-webkit-overflow-scrolling:touch;border:1px solid var(--line);border-radius:10px;margin:18px 0 26px;background:var(--paper)}
table{border-collapse:collapse;width:100%;min-width:660px;font-size:15.5px}
th,td{padding:12px 14px;text-align:left;vertical-align:top;border-bottom:1px solid var(--line)}
thead th{background:#F1E7D2;font-family:'Inter',sans-serif;font-size:13px;letter-spacing:.06em;text-transform:uppercase;color:#54452F}
tbody tr:last-child td{border-bottom:none}
.score{display:inline-block;background:var(--brick);color:#fff;font-weight:700;border-radius:6px;padding:2px 9px;font-size:14.5px;white-space:nowrap}
.score.mid{background:#B07B2E}
.score.low{background:#77685A}
/* buttons */
.btn{display:inline-block;background:var(--brick);color:#fff;font-weight:600;font-size:14.5px;
  padding:8px 14px;border-radius:7px;text-decoration:none;white-space:nowrap}
.btn:hover{background:var(--brick-dark);color:#fff}
.btn.ghost{background:transparent;color:var(--brick);border:1.5px solid var(--brick)}
.btn.ghost:hover{background:#F4E9D4;color:var(--brick-dark)}
.cta-row{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:14px 0 4px}
/* tool sections */
.tool{border-top:2px solid var(--ink);padding-top:8px;margin-top:34px}
.tool-head{display:flex;align-items:baseline;gap:12px;flex-wrap:wrap}
.tool-head h2{margin:8px 0 4px}
.tool-head .bestfor{color:var(--muted);font-style:italic}
.pc{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin:14px 0}
.pc div{background:var(--paper);border:1px solid var(--line);border-radius:8px;padding:14px 16px}
.pc h4{margin:0 0 8px;font-size:14px;letter-spacing:.08em;text-transform:uppercase}
.pc ul{margin:0;padding-left:19px}
.pc li{margin:4px 0;font-size:15.5px}
.pricing-note{background:#F7F0E0;border-left:4px solid var(--mustard);padding:10px 14px;border-radius:0 8px 8px 0;font-size:15.5px}
/* faq */
details{background:var(--paper);border:1px solid var(--line);border-radius:8px;padding:12px 16px;margin:10px 0}
summary{font-weight:600;cursor:pointer;font-family:'Newsreader',Georgia,serif;font-size:18px}
details p{margin:10px 0 4px;color:#463B31}
/* footer */
.site-footer{border-top:2px solid var(--ink);margin-top:56px;background:#F3EADA}
.footer-in{padding:34px 0 26px;display:grid;grid-template-columns:2fr 1fr 1fr;gap:26px}
.site-footer h4{margin:0 0 10px;font-size:14px;letter-spacing:.1em;text-transform:uppercase}
.site-footer ul{list-style:none;margin:0;padding:0}
.site-footer li{margin:6px 0}
.site-footer a{color:var(--ink);text-decoration:none;font-size:15px}
.site-footer a:hover{color:var(--brick)}
.footer-disc{border-top:1px solid var(--line);padding:16px 0 26px;font-size:13.5px;color:var(--muted)}
/* misc */
.pill{display:inline-block;border:1.5px solid var(--brick);color:var(--brick);border-radius:999px;
  padding:3px 12px;font-size:13.5px;font-weight:600;text-decoration:none}
.pill:hover{background:var(--brick);color:#fff}
.method-strip{background:var(--ink);color:var(--cream);border-radius:12px;padding:26px 28px}
.method-strip h2{color:var(--cream)}
.method-strip p{color:#E9DFCE}
.method-strip a{color:var(--mustard)}
@media (max-width:720px){
  .pc{grid-template-columns:1fr}
  .footer-in{grid-template-columns:1fr}
  .hero{padding:36px 0 28px}
  body{font-size:16px}
}
"""


def esc(x):
    return html.escape(str(x), quote=True)


def words(text):
    return len(re.findall(r"[A-Za-z0-9'’-]+", text))


def strip_tags(html_text):
    return re.sub(r"<[^>]+>", " ", html_text)


def score_class(score):
    if score >= 8.5:
        return "score"
    if score >= 7.8:
        return "score mid"
    return "score low"


def og_svg(title, category_label):
    safe = html.escape(title)
    lines, cur = [], ""
    for w in title.split():
        if len(cur) + len(w) + 1 > 34:
            lines.append(cur)
            cur = w
        else:
            cur = (cur + " " + w).strip()
    if cur:
        lines.append(cur)
    tspans = "".join(
        f'<tspan x="70" dy="{0 if i == 0 else 56}">{html.escape(line)}</tspan>'
        for i, line in enumerate(lines[:4]))
    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630">
  <rect width="1200" height="630" fill="#FBF6EE"/>
  <rect width="1200" height="14" fill="#A83C26"/>
  <rect x="70" y="86" width="64" height="8" fill="#D9A441"/>
  <text x="70" y="140" font-family="Arial, sans-serif" font-size="24" letter-spacing="5" fill="#A83C26">{html.escape(category_label.upper())} · ATIV.CC</text>
  <text y="238" font-family="Georgia, serif" font-size="50" font-weight="700" fill="#221D18">{tspans}</text>
  <text x="70" y="556" font-family="Georgia, serif" font-size="30" letter-spacing="4" fill="#221D18">ATIV — Practical picks for creators</text>
</svg>
"""


def header(active=""):
    links = [("Blog", "/blog/"), ("How We Pick", "/how-we-pick/"),
             ("Start Here", "/start-here/"), ("About", "/about/")]
    nav = "".join(f'<a href="{u}">{n}</a>' for n, u in links)
    cats = "".join(
        f'<a href="/categories/{slug}/">{label}</a>'
        for slug, (label, _d) in CATEGORIES.items())
    return f"""<header class="site-header"><div class="wrap header-in">
  <a class="logo" href="/" aria-label="ATIV home"><img src="/assets/logo.svg" alt="ATIV" height="38"></a>
  <nav class="main-nav">{nav}</nav>
</div><div class="wrap" style="padding-bottom:10px;display:flex;gap:16px;flex-wrap:wrap;font-size:13.5px">
  <span style="color:var(--muted);font-weight:600">Browse:</span>{cats}
</div></header>"""


def footer():
    cats = "".join(
        f'<li><a href="/categories/{slug}/">{label}</a></li>'
        for slug, (label, _d) in CATEGORIES.items())
    return f"""<footer class="site-footer"><div class="wrap footer-in">
  <div>
    <img src="/assets/logo.svg" alt="ATIV" height="34" style="margin-bottom:10px">
    <p style="margin:0;color:#463B31;font-size:15px;max-width:26em">Practical picks: the best tools for creators &amp; productive teams. Short lists, honest trade-offs, scores you can inspect.</p>
  </div>
  <div><h4>Categories</h4><ul>{cats}</ul></div>
  <div><h4>ATIV</h4><ul>
    <li><a href="/blog/">All comparisons</a></li>
    <li><a href="/how-we-pick/">How we pick</a></li>
    <li><a href="/start-here/">Start here</a></li>
    <li><a href="/about/">About</a></li>
    <li><a href="/affiliate-disclosure/">Affiliate disclosure</a></li>
    <li><a href="/privacy/">Privacy</a></li>
    <li><a href="/terms/">Terms</a></li>
  </ul></div>
</div>
<div class="wrap footer-disc">{esc(DISCLOSURE)} ATIV is an independent editorial site; product names belong to their owners. &copy; {YEAR} ATIV (ativ.cc).</div>
</footer>"""


def page(title, description, path, body, extra_head="", main_class="wrap", og_image="/assets/og-default.png"):
    canonical = BASE + path
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{esc(title)}</title>
<meta name="description" content="{esc(description)}">
<link rel="canonical" href="{canonical}">
<meta property="og:type" content="website">
<meta property="og:site_name" content="ATIV">
<meta property="og:title" content="{esc(title)}">
<meta property="og:description" content="{esc(description)}">
<meta property="og:url" content="{canonical}">
<meta property="og:image" content="{BASE}{og_image}">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="/assets/logo.svg" type="image/svg+xml">
<link rel="icon" href="/assets/favicon-32.png" type="image/png" sizes="32x32">
<link rel="apple-touch-icon" href="/assets/apple-touch-180.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Newsreader:opsz,wght@6..72,500;6..72,600;6..72,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/style.css">
{extra_head}</head>
<body>
<a class="skip" href="#main">Skip to content</a>
{header()}
<main id="main" class="{main_class}">
{body}
</main>
{footer()}
</body>
</html>
"""


def cta_row(tool, primary_label=None):
    label = primary_label or f"Visit {tool['name']} (official site)"
    return (f'<div class="cta-row">'
            f'<a class="btn" href="{esc(tool["url"])}" target="_blank" rel="noopener">{esc(label)}</a>'
            f'<span class="small">Plain link — ATIV earns nothing from it.</span>'
            f'</div>')


def comparison_table(tools, caption):
    rows = ""
    for t in tools:
        rows += (f'<tr><td><strong>{esc(t["name"])}</strong></td>'
                 f'<td>{esc(t["best_for"])}</td>'
                 f'<td>{esc(t["price"])}</td>'
                 f'<td><span class="{score_class(t["score"])}">{t["score"]:.1f}</span></td>'
                 f'<td><a class="btn" href="{esc(t["url"])}" target="_blank" rel="noopener">Visit site</a></td></tr>\n')
    return (f'<div class="table-scroll"><table><caption style="text-align:left;padding:12px 14px 0;font-weight:600">{esc(caption)}</caption>'
            f'<thead><tr><th>Tool</th><th>Best for</th><th>Starting price</th><th>Score</th><th>Official site</th></tr></thead>'
            f'<tbody>{rows}</tbody></table></div>')


def quick_picks_table(tools):
    top = sorted(tools, key=lambda t: -t["score"])[:3]
    rows = ""
    labels = ["Best overall", "Runner-up", "Also consider"]
    for i, t in enumerate(top):
        rows += (f'<tr><td>{labels[i]}</td>'
                 f'<td><strong>{esc(t["name"])}</strong></td>'
                 f'<td>{esc(t["best_for"])}</td>'
                 f'<td><span class="{score_class(t["score"])}">{t["score"]:.1f}</span></td></tr>\n')
    return (f'<div class="table-scroll"><table>'
            f'<thead><tr><th>Pick</th><th>Tool</th><th>Best for</th><th>Score</th></tr></thead>'
            f'<tbody>{rows}</tbody></table></div>')


def article_body(a, articles_by_slug):
    tools_sorted = sorted(a["tools"], key=lambda t: -t["score"])
    parts = []
    parts.append(f"""<div class="article-head narrow">
  <a class="pill" href="/categories/{a['category']}/">{esc(a['category_label'])}</a>
  <h1>{esc(a['title'])}</h1>
  <div class="byline"><span>By ATIV Editorial</span><span>Updated {esc(a['updated'])}</span><span>{a['_read']} min read</span></div>
  <div class="disclosure-box"><strong>Disclosure:</strong> {esc(DISCLOSURE)} <a href="/affiliate-disclosure/">Full disclosure</a> · <a href="/how-we-pick/">How we score</a></div>
</div>
<article class="narrow">""")
    for p in a["hook"]:
        parts.append(f"<p>{esc(p)}</p>")
    parts.append("<h2>Quick picks</h2>")
    parts.append(f"<p>{esc(a['quick_picks_intro'])}</p>")
    parts.append(quick_picks_table(a["tools"]))
    parts.append("<h2>The full comparison</h2>")
    parts.append(comparison_table(tools_sorted, f"{a['title']} — all picks compared"))
    for t in tools_sorted:
        pros = "".join(f"<li>{esc(x)}</li>" for x in t["pros"])
        cons = "".join(f"<li>{esc(x)}</li>" for x in t["cons"])
        parts.append(f"""<section class="tool">
  <div class="tool-head"><h2>{esc(t['name'])}</h2><span class="{score_class(t['score'])}">{t['score']:.1f} / 10</span><span class="bestfor">{esc(t['best_for'])}</span></div>
  <p>{esc(t['take'])}</p>
  <p><strong>Who it’s for:</strong> {esc(t['who'])}</p>
  <div class="pc"><div><h4>Pros</h4><ul>{pros}</ul></div><div><h4>Cons</h4><ul>{cons}</ul></div></div>
  <p class="pricing-note"><strong>Pricing note:</strong> {esc(t['pricing_note'])}</p>
  {cta_row(t)}
</section>""")
    parts.append("<h2>Verdict: who should choose what</h2>")
    for p in a["verdict"]:
        parts.append(f"<p>{esc(p)}</p>")
    parts.append("<h2>FAQ</h2>")
    for f in a["faq"]:
        parts.append(f"<details><summary>{esc(f['q'])}</summary><p>{esc(f['a'])}</p></details>")
    rel = [articles_by_slug[s] for s in a.get("related", []) if s in articles_by_slug]
    if rel:
        links = "".join(
            f'<li><a href="/blog/{r["slug"]}/">{esc(r["title"])}</a></li>' for r in rel)
        parts.append(f"<h2>Keep reading</h2><ul>{links}</ul>")
    parts.append(f'<div class="disclosure-box"><strong>Disclosure:</strong> {esc(DISCLOSURE)} '
                 f'Scores follow our <a href="/how-we-pick/">methodology</a>; prices are the vendors’ published prices as of the date shown and change often.</div>')
    parts.append("</article>")
    return "\n".join(parts)


def article_jsonld(a):
    article = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": a["title"],
        "description": a["description"],
        "datePublished": a["date"],
        "dateModified": a["updated"],
        "author": {"@type": "Organization", "name": "ATIV Editorial", "url": BASE + "/about/"},
        "publisher": {"@type": "Organization", "name": "ATIV", "url": BASE + "/"},
        "mainEntityOfPage": BASE + f"/blog/{a['slug']}/",
        "image": BASE + f"/assets/og/{a['slug']}.png",
    }
    faq = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {"@type": "Question", "name": f["q"],
             "acceptedAnswer": {"@type": "Answer", "text": f["a"]}}
            for f in a["faq"]],
    }
    return (f'<script type="application/ld+json">{json.dumps(article)}</script>\n'
            f'<script type="application/ld+json">{json.dumps(faq)}</script>')


def card(a):
    return f"""<div class="card">
  <span class="cat">{esc(a['category_label'])}</span>
  <h3><a href="/blog/{a['slug']}/">{esc(a['title'])}</a></h3>
  <p>{esc(a['description'])}</p>
  <span class="meta">Updated {esc(a['updated'])} · {a['_read']} min read</span>
</div>"""


def render_generic(pg, path):
    paras = "".join(f"<p>{esc(p)}</p>" for p in pg["paras"])
    body = f"""<div class="article-head narrow"><h1>{esc(pg['title'])}</h1></div>
<article class="narrow">{paras}</article>"""
    if path == "/about/" and (DIST / "video" / "promo-35s.mp4").is_file():
        body += """<div class="narrow"><h2 class="serif">Watch: how ATIV ranks tools (35 seconds)</h2>
<p><video controls preload="none" poster="/video/thumbnail.png" width="360" style="max-width:100%;border-radius:12px" src="/video/promo-35s.mp4"></video></p></div>"""
    return page(f"{pg['title']} — ATIV", pg["description"], path, body)


def build():
    if DIST.exists():
        shutil.rmtree(DIST)
    (DIST / "assets" / "og").mkdir(parents=True)
    (DIST / "assets" / "style.css").write_text(CSS.strip() + "\n", encoding="utf-8")
    (DIST / "assets" / "logo.svg").write_text(LOGO_SVG, encoding="utf-8")
    (DIST / "assets" / "og-default.svg").write_text(
        og_svg("Practical picks for creators & productive teams", "ATIV"), encoding="utf-8")
    # --- Generated PNG fallbacks (stdlib only, re-runnable): guarantee every
    # PNG the templates reference exists even when the canonical brand files
    # are not present on this machine. Real brand assets copied in the HQ
    # step below override these fallbacks. ---
    def _png_bytes(w, h, pixel):
        def chunk(typ, data):
            c = struct.pack(">I", len(data)) + typ + data
            return c + struct.pack(">I", zlib.crc32(typ + data) & 0xFFFFFFFF)
        raw = b"".join(b"\x00" + b"".join(bytes(pixel(x, y)) for x in range(w)) for y in range(h))
        ihdr = struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)
        return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) +
                chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))
    _brick = (168, 60, 38); _mustard = (217, 164, 65); _cream = (251, 246, 238)
    def _og_plate(x, y):
        if y < 48 or y >= 582: return _brick
        if 64 <= x < 1136 and 292 <= y < 304: return _mustard
        return _cream
    def _icon(lo, hi):
        return lambda x, y: _mustard if (lo < x < hi and lo < y < hi) else _brick
    (DIST / "assets" / "og-default.png").write_bytes(_png_bytes(1200, 630, _og_plate))
    (DIST / "assets" / "favicon-32.png").write_bytes(_png_bytes(32, 32, _icon(10, 22)))
    (DIST / "assets" / "apple-touch-180.png").write_bytes(_png_bytes(180, 180, _icon(60, 120)))
    # --- HQ integration: canonical brand assets + promo video ---
    _brand = ROOT.parent.parent / "images" / "brand" / "ativ"
    def _cpy(src, dst):
        if src.is_file():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dst)
    _cpy(_brand / "og-default.png", DIST / "assets" / "og-default.png")
    _cpy(_brand / "favicon-32.png", DIST / "assets" / "favicon-32.png")
    _cpy(_brand / "apple-touch-180.png", DIST / "assets" / "apple-touch-180.png")
    _cpy(_brand / "logo-mark.svg", DIST / "assets" / "logo-mark.svg")
    _cpy(_brand / "logo-lockup.svg", DIST / "assets" / "logo-lockup.svg")
    _cpy(_brand / "logo-on-dark.svg", DIST / "assets" / "logo-on-dark.svg")
    for _cov in ("article-cover-1.png", "article-cover-2.png", "article-cover-3.png", "article-cover-template.png"):
        _cpy(_brand / _cov, DIST / "assets" / "covers" / _cov)
    _vdir = ROOT.parent.parent / "videos" / "ativ"
    _cpy(_vdir / "promo-35s.mp4", DIST / "video" / "promo-35s.mp4")
    _cpy(_vdir / "thumbnail.png", DIST / "video" / "thumbnail.png")

    articles = []
    for f in sorted((CONTENT / "articles").glob("*.json")):
        a = json.loads(f.read_text(encoding="utf-8"))
        text_bits = list(a["hook"]) + [a["quick_picks_intro"]] + list(a["verdict"])
        for t in a["tools"]:
            text_bits += [t["take"], t["who"], t["pricing_note"]] + t["pros"] + t["cons"]
        for fqa in a["faq"]:
            text_bits += [fqa["q"], fqa["a"]]
        a["_words"] = words(" ".join(text_bits))
        a["_read"] = max(4, round(a["_words"] / 200))
        articles.append(a)
    articles.sort(key=lambda a: a["slug"])
    by_slug = {a["slug"]: a for a in articles}
    pages = json.loads((CONTENT / "pages.json").read_text(encoding="utf-8"))

    routes = []  # (path, lastmod)

    def emit(path, html_text):
        out = DIST / path.lstrip("/") / "index.html" if path != "/" else DIST / "index.html"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(html_text, encoding="utf-8")
        routes.append(path)

    # --- Home ---
    featured = [by_slug[s] for s in [
        "best-ai-writing-tools-for-creators",
        "best-ai-video-tools-for-short-form-creators",
        "best-free-productivity-apps-2026"] if s in by_slug]
    feat_cards = "\n".join(card(a) for a in featured)
    all_cards = "\n".join(card(a) for a in articles)
    cat_cards = "".join(
        f'<a class="cat-card" href="/categories/{slug}/"><strong>{label}</strong><span>{desc}</span></a>'
        for slug, (label, desc) in CATEGORIES.items())
    home_body = f"""<section class="hero"><div class="narrow" style="margin:0">
  <span class="kicker">ATIV · Comparison guides for creators</span>
  <h1>Practical picks: the best tools for creators &amp; productive teams.</h1>
  <p class="lede">Short, honest roundups of the software people actually publish with — writing, video, design, notes, automation. Every score follows a published rubric, and every list names the trade-offs the vendor pages leave out.</p>
  <div class="cta-row"><a class="btn" href="/start-here/">Start here</a><a class="btn ghost" href="/how-we-pick/">Read our methodology</a></div>
  <hr class="rule">
  <p style="color:var(--muted);font-size:15px;margin:0">{esc(DISCLOSURE)}</p>
</div></section>
<section class="section"><h2>Featured comparisons</h2><p class="sub">The three guides most readers start with.</p>
<div class="grid">{feat_cards}</div></section>
<section class="section"><h2>Browse by job</h2><p class="sub">Pick the bottleneck, not the trend.</p>
<div class="cat-grid">{cat_cards}</div></section>
<section class="section"><div class="method-strip"><h2>Scores you can argue with</h2>
<p>Every tool is scored 1–10 on four things: ease, pricing clarity, creator fit, and export options. No all-9.9 tables, no paid placements. If our weights are wrong for your work, the rubric shows its working so you can re-rank the list yourself.</p>
<p><a href="/how-we-pick/">How we pick tools at ATIV</a></p></div></section>
<section class="section"><h2>All comparisons</h2><div class="grid">{all_cards}</div></section>"""
    emit("/", page("ATIV — Practical picks: the best tools for creators & productive teams",
                   "Honest, short comparisons of AI writing, video, image, note-taking, automation and productivity tools for creators. Scores you can inspect, trade-offs included.",
                   "/", home_body))

    # --- Blog index ---
    blog_body = f"""<div class="article-head narrow"><h1>All comparisons</h1>
<p style="color:var(--muted)">Every ATIV roundup, newest rubric, same disclosure: {esc(DISCLOSURE)}</p></div>
<div class="grid">{"".join(card(a) for a in articles)}</div>"""
    emit("/blog/", page("All comparisons — ATIV",
                         "Browse every ATIV comparison guide: AI writing, video, image, note-taking, automation and free productivity tools for creators.",
                         "/blog/", blog_body))

    # --- Articles ---
    counts = {}
    for a in articles:
        (DIST / "assets" / "og" / f"{a['slug']}.svg").write_text(
            og_svg(a["title"], a["category_label"]), encoding="utf-8")
        _ogpng = ROOT / "og-src" / f"{a['slug']}.png"
        _ogdst = DIST / "assets" / "og" / f"{a['slug']}.png"
        if _ogpng.is_file():
            shutil.copyfile(_ogpng, _ogdst)
        else:
            _ogdst.write_bytes(_png_bytes(1200, 630, _og_plate))
        body = article_body(a, by_slug)
        full = page(f"{a['title']} — ATIV", a["description"], f"/blog/{a['slug']}/",
                    body, extra_head=article_jsonld(a), og_image=f"/assets/og/{a['slug']}.png")
        main_html = full.split("<main", 1)[1].split("</main>")[0]
        counts[a["slug"]] = words(strip_tags(main_html))
        emit(f"/blog/{a['slug']}/", full)

    # --- How we pick ---
    hw = pages["how_we_pick"]
    secs = ""
    hw_words = 0
    for s in hw["sections"]:
        secs += f"<h2>{esc(s['h'])}</h2>" + "".join(f"<p>{esc(p)}</p>" for p in s["paras"])
        hw_words += words(" ".join(s["paras"]))
    hw_body = f"""<div class="article-head narrow"><h1>{esc(hw['title'])}</h1>
<div class="disclosure-box"><strong>Disclosure:</strong> {esc(DISCLOSURE)} <a href="/affiliate-disclosure/">Full disclosure</a></div></div>
<article class="narrow">{secs}</article>"""
    emit("/how-we-pick/", page("How We Pick Tools at ATIV — ATIV", hw["description"],
                               "/how-we-pick/", hw_body))

    # --- Categories ---
    for slug, (label, desc) in CATEGORIES.items():
        in_cat = [a for a in articles if a["category"] == slug]
        cards = "".join(card(a) for a in in_cat) or "<p>Guides are on the way.</p>"
        tools_line = ""
        if in_cat:
            names = []
            for a in in_cat:
                for t in a["tools"]:
                    if t["name"] not in names:
                        names.append(t["name"])
            tools_line = (f'<p style="color:var(--muted)">Tools covered here so far: '
                          + ", ".join(esc(n) for n in names) + ".</p>")
        body = f"""<div class="article-head narrow"><span class="kicker">Category</span>
<h1>{esc(label)} tools</h1><p style="color:var(--muted)">{esc(desc)}</p>{tools_line}</div>
<div class="grid">{cards}</div>
<p style="margin-top:26px">Scores on ATIV follow one rubric across every category — <a href="/how-we-pick/">read how we pick</a>.</p>"""
        emit(f"/categories/{slug}/",
             page(f"Best {label} Tools for Creators — ATIV",
                  f"ATIV comparisons of {label.lower()} tools for creators and productive teams: {desc}",
                  f"/categories/{slug}/", body))

    # --- Simple pages ---
    emit("/start-here/", render_generic(pages["start_here"], "/start-here/"))
    # start-here gets flagship links appended
    sh = DIST / "start-here" / "index.html"
    flagship = "".join(
        f'<li><a href="/blog/{s}/">{esc(by_slug[s]["title"])}</a></li>'
        for s in ["best-ai-writing-tools-for-creators",
                  "best-ai-video-tools-for-short-form-creators",
                  "best-ai-note-taking-tools-for-solopreneurs"] if s in by_slug)
    sh.write_text(sh.read_text(encoding="utf-8").replace(
        "</article>", f"<h2>The three flagship guides</h2><ul>{flagship}</ul></article>"),
        encoding="utf-8")
    emit_done = None
    emit("/about/", render_generic(pages["about"], "/about/"))
    emit("/affiliate-disclosure/", render_generic(pages["affiliate_disclosure"], "/affiliate-disclosure/"))
    emit("/privacy/", render_generic(pages["privacy"], "/privacy/"))
    emit("/terms/", render_generic(pages["terms"], "/terms/"))

    # --- 404 page (written outside the sitemap routes) ---
    _nf = page("Page Not Found — ATIV",
               "That page does not exist on ATIV. Start from a comparison roundup instead.",
               "/404",
               '<p class="kicker">404</p><h1>That page is not on the shelf</h1>'
               '<p>The link may be wrong, or the article may have been retired. '
               'Start from a roundup instead:</p>'
               '<p><a class="btn" href="/start-here/">Start here</a> '
               '<a class="btn ghost" href="/">Back to home</a></p>')
    (DIST / "404.html").write_text(_nf, encoding="utf-8")

    # --- robots + sitemap ---
    (DIST / "robots.txt").write_text(
        f"User-agent: *\nAllow: /\nSitemap: {BASE}/sitemap.xml\n", encoding="utf-8")
    sm = ['<?xml version="1.0" encoding="UTF-8"?>',
          '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for path in routes:
        loc = BASE + path
        sm.append(f"<url><loc>{loc}</loc><lastmod>2026-11-04</lastmod></url>")
    sm.append("</urlset>")
    (DIST / "sitemap.xml").write_text("\n".join(sm) + "\n", encoding="utf-8")

    print(f"Built {len(routes)} routes")
    print(f"Sitemap URLs: {len(routes)}")
    print(f"How-we-pick body words: {hw_words}")
    for slug, c in counts.items():
        print(f"ARTICLE {slug}: {c} words (main incl. template)")
    return counts


if __name__ == "__main__":
    build()
