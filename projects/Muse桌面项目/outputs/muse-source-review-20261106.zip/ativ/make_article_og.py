#!/usr/bin/env python3
"""Generate per-article OG images (1200x630 PNG) for ATIV in brand palette.
Run once (or when article titles change): python3 make_article_og.py
Output: og-src/<slug>.png — build.py copies these into dist/assets/og/.
"""
import json
import textwrap
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "og-src"
OUT.mkdir(exist_ok=True)

SERIF_B = "/usr/share/fonts/truetype/noto/NotoSerifDisplay-Bold.ttf"
SANS_B = "/usr/share/fonts/truetype/noto/NotoSansDisplay-Bold.ttf"
SANS_R = "/usr/share/fonts/truetype/noto/NotoSansDisplay-Regular.ttf"

CREAM = (251, 246, 238)
BRICK = (168, 60, 38)
MUSTARD = (217, 164, 65)
INK = (34, 29, 24)
MUTED = (110, 98, 87)


def wrap(draw, text, font, max_w):
    words, lines, cur = text.split(), [], ""
    for w in words:
        trial = (cur + " " + w).strip()
        if draw.textlength(trial, font=font) <= max_w:
            cur = trial
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def main():
    for f in sorted((ROOT / "content" / "articles").glob("*.json")):
        a = json.loads(f.read_text(encoding="utf-8"))
        img = Image.new("RGB", (1200, 630), CREAM)
        d = ImageDraw.Draw(img)
        d.rectangle([0, 0, 26, 630], fill=BRICK)
        d.rectangle([74, 92, 74 + 54, 100], fill=MUSTARD)
        cat_font = ImageFont.truetype(SANS_B, 30)
        d.text((74, 116), a["category_label"].upper(), font=cat_font, fill=BRICK)
        title_font = ImageFont.truetype(SERIF_B, 66)
        lines = wrap(d, a["title"], title_font, 1050)[:3]
        y = 190
        for ln in lines:
            d.text((74, y), ln, font=title_font, fill=INK)
            y += 82
        brand_font = ImageFont.truetype(SANS_B, 34)
        foot_font = ImageFont.truetype(SANS_R, 28)
        d.text((74, 540), "ATIV", font=brand_font, fill=BRICK)
        d.text((190, 545), "ativ.cc — practical picks, honestly ranked", font=foot_font, fill=MUTED)
        out = OUT / f"{a['slug']}.png"
        img.save(out)
        print("wrote", out, img.size)


if __name__ == "__main__":
    main()
