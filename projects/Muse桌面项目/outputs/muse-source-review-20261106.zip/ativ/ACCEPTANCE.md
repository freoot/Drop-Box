# ATIV — Acceptance Checklist (vs. Spec 02 Definition of Done)

Verified on 2026-11-04 by running `python3 build.py` and scripted checks
against the built HTML in `dist/`. Word counts below are measured from the
built article HTML (`<main>` content, tags stripped — includes tables and
template text).

## Definition of Done

- [x] **Local build succeeds** — `python3 build.py` (stdlib only) builds
      cleanly and prints its own verification report. README is in English
      and covers build, preview, and Cloudflare Pages deployment.
- [x] **≥6 roundups + 1 methodology, template structure** — 6 roundups, each
      rendered from the same template: hook → quick picks (Top 3 table) →
      full comparison table → per-tool sections (who it's for / pros /
      cons / pricing note) → verdict → FAQ.
  - best-ai-writing-tools-for-creators — 1,784 words
  - best-ai-video-tools-for-short-form-creators — 1,765 words
  - best-ai-image-tools-for-designers-on-a-budget — 1,722 words
  - best-ai-note-taking-tools-for-solopreneurs — 1,787 words
  - best-automation-tools-for-creators — 1,832 words
  - best-free-productivity-apps-2026 — 1,939 words
  - /how-we-pick methodology — 1,077 words of body copy (plus headings)
- [x] **Comparison table + disclosure in every article** — scripted check:
      each article page contains 2 tables (quick picks + full comparison)
      and the exact disclosure sentence *"We may earn a commission if you
      buy through links on this page. It never changes our rankings."*
      near the top, repeated above the footer; the footer of every page
      sitewide carries it too.
- [x] **Disclosure / Privacy / Terms / About / Start Here pages** — all
      built: /affiliate-disclosure/, /privacy/, /terms/, /about/,
      /start-here/ (with links to the three flagship guides).
- [x] **SEO** — unique title + meta description on all 19 pages (verified
      unique), canonical `https://ativ.cc/...` on every page, Article +
      FAQPage JSON-LD on every article (FAQ entries in JSON-LD match the
      on-page FAQ count exactly: 4, 4, 4, 4, 5, 5), per-article OG SVG
      cards + site OG default, `dist/robots.txt`, `dist/sitemap.xml`
      with **19 URLs**.
- [x] **No Chinese in the UI** — scripted CJK scan of every file in
      `dist/`: zero matches.
- [x] **Mobile readability** — all comparison tables sit in `.table-scroll`
      containers (`overflow-x:auto`, table `min-width:660px`), so tables
      scroll horizontally inside their card instead of breaking layout;
      pros/cons grids and footer collapse to one column under 720px.
- [x] **All routes live, no dead internal links** — 19 routes built
      (/, /blog, 6 articles, /how-we-pick, 5 categories, /start-here,
      /about, /affiliate-disclosure, /privacy, /terms); scripted link
      check found no unresolved internal hrefs.
- [x] **Scores vary and are explained** — per-article scores span
      7.3–9.3 (never all 9.9); /how-we-pick defines the 1–10 rubric:
      ease (30%), pricing clarity (25%), creator fit (30%), export
      options (15%).
- [x] **Anti-slop constraints** — brick/mustard/cream editorial palette,
      Newsreader + Inter, no gradients, no testimonial walls, no hype
      claims (scripted grep for hype phrases found only the Terms page's
      "we do not guarantee" disclaimer).
- [x] **Brand** — no files existed under `images/brand/ativ/` at build
      time, so the site ships its own hand-written SVG wordmark
      (`dist/assets/logo.svg`); HQ can swap in final brand files later.

## Known TODOs (not DoD blockers)

- Affiliate CTA buttons are `href="#"` + `data-affiliate="TODO"`
  (10 per article) until HQ supplies real program links; plain "Visit"
  links already point to official vendor sites.
- OG images are generated SVG cards. Some social platforms prefer raster;
  swap in 1200×630 PNGs when Visual delivers final brand assets.
- Not yet deployed: no Cloudflare Pages project has been connected from
  this workspace; deploy is an HQ step per the README.
