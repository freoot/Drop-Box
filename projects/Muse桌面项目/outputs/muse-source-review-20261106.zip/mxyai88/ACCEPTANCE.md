# ACCEPTANCE — mxyai88.com (Site A) self-check

Checked against spec `01-mxyai88-directory.md` Definition of Done and the
fixed HQ decisions, on the built output in `dist/` (not just the source).

## Spec DoD

- [x] `README.md` in English; local build succeeds (`python3 build.py`,
  zero dependencies); preview via `python3 -m http.server -d dist 8000`
- [x] All IA routes accessible, no broken main links — verified by walking
  all 72 generated pages and resolving every internal href: 0 missing
  - `/`, `/categories/`, 11 × `/category/[slug]/`, 50 × `/tool/[slug]/`,
    `/featured/`, `/submit/`, `/about/`, `/guides/` + 2 guide articles,
    `/affiliate-disclosure/`, `/privacy/`, `/terms/`
- [x] ≥40 tools with complete schema fields — **50 tools**, every required
  field validated programmatically; ≥3 featured — **5 featured**
  (Jasper, Descript, Zapier, Cursor, Midjourney) with badges and
  top placement in category + home
- [x] Get Featured form present with explicit placeholder: mailto form,
  TODO comments in `build.py`, placeholder-pricing note on the page
- [x] Affiliate Disclosure / Privacy / Terms pages exist and are linked in
  every page footer (Disclosure · Privacy · Terms)
- [x] SEO: unique `<title>` + meta description on all 72 pages (0 duplicate
  titles), canonical `https://mxyai88.com/...`, OG/Twitter tags,
  `robots.txt`, `sitemap.xml` with **72 URLs**, JSON-LD `ItemList` on
  category pages and `SoftwareApplication` on tool pages (verified in HTML)
- [x] No Chinese in production UI — full `dist/` scan for CJK ranges:
  **0 files matched**
- [x] 375px / 1280px layout: fluid grid (`auto-fill, minmax(262px, 1fr)`),
  wrapping nav/filters, single-column collapse under 640px, no fixed-width
  overflow elements (CSS-audited; no live-device render in this pass)
- [x] Client-side search on home (name/tags/category) + pricing filters on
  home and category pages, plain JS, no dependencies
- [x] Accessibility basics: skip link, focus-visible outlines, real
  buttons with `aria-pressed` for filters, alt text on all images,
  semantic H1 per page (tool pages: H1 = tool name)
- [x] Honest editorial model: scores labeled “Editorial score”, no fake
  review counts, no star ratings, no YMYL or earnings claims;
  descriptions are original write-ups, `affiliateUrl` null throughout
- [x] Brand per HQ: pine #0C4A34 / amber #E9B44C / warm paper #F7F5F0,
  Archivo + Inter, hand-written SVG node-grid “M” logo, generated
  favicon.svg/png and og.png (no brand-worker files were present in
  `images/brand/mxyai88/` at build time — reconcile at integration)

## Not done / TODO (honest)

- [ ] Forms are mailto placeholders, not a real endpoint (TODO before
  paid launch)
- [ ] Featured package prices are introductory placeholders pending HQ
  confirmation
- [ ] No real affiliate URLs yet (all null by design at MVP)
- [ ] Tool logos are generated initial-letter placeholders, not vendor
  brand assets
- [ ] Privacy/Terms are plain-language templates pending counsel review
- [ ] Not yet deployed to Cloudflare (no preview URL); `dist/` is ready
  for direct Pages upload
