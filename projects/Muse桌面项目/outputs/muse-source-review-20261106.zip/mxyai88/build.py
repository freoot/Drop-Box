#!/usr/bin/env python3
"""MXY AI — dependency-free static site generator (Python 3 stdlib only).

Reads data/tools.json + data/categories.json and writes a complete static
site into dist/, ready to upload to Cloudflare Pages as-is.

Usage:  python3 build.py
"""
import json, os, html, struct, zlib, shutil
from datetime import date

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(ROOT, "data")
DIST = os.path.join(ROOT, "dist")
BASE = "https://mxyai88.com"
TODAY = date.today().isoformat()

tools = json.load(open(os.path.join(DATA, "tools.json")))
cats = json.load(open(os.path.join(DATA, "categories.json")))
CAT = {c["slug"]: c for c in cats}
TOOLS = {t["slug"]: t for t in tools}

FEATURED = sorted([t for t in tools if t["featured"]], key=lambda t: t["featuredRank"] or 99)
LATEST = sorted(tools, key=lambda t: t["dateAdded"], reverse=True)

def esc(s): return html.escape(str(s), quote=True)

def initials(name):
    parts = [p for p in name.replace(".", " ").replace("-", " ").split() if p]
    if len(parts) == 1: return parts[0][:2].upper()
    return (parts[0][0] + parts[1][0]).upper()

# ---------- assets ----------
CSS = """
:root{--pine:#0C4A34;--pine2:#0A3B2A;--amber:#E9B44C;--paper:#F7F5F0;--ink:#101613;--line:#DDD8CC;--card:#FFFDF8;--muted:#5A655E}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:var(--paper);color:var(--ink);font-family:Inter,system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;line-height:1.55}
h1,h2,h3,.brand{font-family:Archivo,Inter,system-ui,sans-serif;letter-spacing:-.01em}
a{color:var(--pine)}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:3px solid var(--amber);outline-offset:2px}
.wrap{max-width:1180px;margin:0 auto;padding:0 20px}
.skip{position:absolute;left:-999px;top:0;background:var(--pine);color:#fff;padding:8px 14px;z-index:50}
.skip:focus{left:8px;top:8px}
header.site{border-bottom:2px solid var(--ink);background:var(--paper);position:sticky;top:0;z-index:20}
.nav{display:flex;align-items:center;gap:22px;padding:12px 0;flex-wrap:wrap}
.brand{display:flex;align-items:center;gap:10px;text-decoration:none;color:var(--ink);font-weight:800;font-size:1.25rem}
.nav nav{display:flex;gap:16px;flex-wrap:wrap;margin-left:auto}
.nav nav a{color:var(--ink);text-decoration:none;font-weight:600;font-size:.95rem}
.nav nav a:hover{color:var(--pine);text-decoration:underline}
.btn{display:inline-block;background:var(--pine);color:#fff;border:2px solid var(--pine);padding:9px 18px;border-radius:6px;font-weight:700;text-decoration:none;cursor:pointer;font-size:.95rem}
.btn:hover{background:var(--pine2)}
.btn.amber{background:var(--amber);border-color:var(--amber);color:var(--ink)}
.btn.ghost{background:transparent;color:var(--pine)}
.btn.small{padding:6px 12px;font-size:.88rem}
.hero{padding:52px 0 34px;border-bottom:1px solid var(--line)}
.hero h1{font-size:2.6rem;line-height:1.08;margin:0 0 14px;max-width:16em}
.hero h1 em{font-style:normal;background:linear-gradient(transparent 62%,var(--amber) 62%)}
.hero p.lede{font-size:1.15rem;color:#33413A;max-width:44em;margin:0 0 22px}
.searchbar{display:flex;gap:10px;max-width:640px;flex-wrap:wrap}
.searchbar input{flex:1;min-width:230px;padding:12px 14px;border:2px solid var(--ink);border-radius:6px;font-size:1rem;background:#fff}
.kicker{font-size:.8rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--pine);margin:0 0 10px}
section.block{padding:36px 0 8px}
section.block h2{font-size:1.7rem;margin:0 0 6px}
section.block .sub{color:var(--muted);margin:0 0 20px;max-width:46em}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(262px,1fr));gap:18px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:18px;display:flex;flex-direction:column;gap:8px}
.card.top{border:2px solid var(--pine)}
.card .row{display:flex;align-items:center;gap:12px}
.card img.logo{width:46px;height:46px;border-radius:9px;flex:none}
.card h3{margin:0;font-size:1.12rem}
.card h3 a{color:var(--ink);text-decoration:none}
.card h3 a:hover{text-decoration:underline}
.card p{margin:0;color:#33413A;font-size:.94rem}
.meta{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:auto}
.badge{display:inline-block;font-size:.72rem;font-weight:800;letter-spacing:.06em;text-transform:uppercase;padding:3px 8px;border-radius:20px;border:1px solid var(--ink)}
.badge.feat{background:var(--amber);border-color:var(--amber)}
.badge.price{background:#fff}
.score{font-size:.85rem;color:var(--pine);font-weight:700}
.card .actions{display:flex;gap:8px;margin-top:10px}
.catgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:14px}
.catcard{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:16px;text-decoration:none;color:var(--ink);display:block}
.catcard:hover{border-color:var(--pine)}
.catcard h3{margin:0 0 4px;font-size:1.05rem}
.catcard p{margin:0;color:var(--muted);font-size:.9rem}
.catcard .n{color:var(--pine);font-weight:700;font-size:.85rem}
.filters{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 20px}
.filters button{background:#fff;border:2px solid var(--ink);border-radius:20px;padding:6px 14px;font-weight:700;cursor:pointer;font-size:.9rem}
.filters button[aria-pressed="true"]{background:var(--pine);color:#fff;border-color:var(--pine)}
.cta-band{background:var(--pine);color:#F3EFE3;border-radius:12px;padding:30px;margin:40px 0}
.cta-band h2{color:#fff;margin-top:0}
.cta-band p{max-width:44em}
table.packages{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line)}
table.packages th,table.packages td{padding:12px 14px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
table.packages th{background:#EFEAE0}
form.stack{display:grid;gap:14px;max-width:620px}
form.stack label{font-weight:700;display:grid;gap:6px}
form.stack input,form.stack select,form.stack textarea{padding:10px 12px;border:2px solid #B9B2A2;border-radius:6px;font:inherit;background:#fff}
.two{display:grid;grid-template-columns:1fr 1fr;gap:22px}
.proscons{display:grid;grid-template-columns:1fr 1fr;gap:18px}
.proscons .box{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:18px}
.proscons ul{margin:8px 0 0;padding-left:20px}
article.guide{max-width:760px}
article.guide p,article.guide li{font-size:1.03rem}
article.guide h2{margin-top:30px}
footer.site{border-top:2px solid var(--ink);margin-top:56px;padding:26px 0 40px;background:#EFEAE0}
footer.site .cols{display:flex;gap:28px;flex-wrap:wrap;justify-content:space-between}
footer.site a{color:var(--ink)}
footer.site p{color:var(--muted);font-size:.9rem;max-width:52em}
.small{font-size:.88rem;color:var(--muted)}
.hidden{display:none!important}
.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap;border:0}
.noresults{border:2px dashed #B9B2A2;border-radius:10px;padding:22px;text-align:center;margin-top:14px}
@media (max-width:640px){
 .hero h1{font-size:1.9rem}
 .two,.proscons{grid-template-columns:1fr}
 .nav{gap:12px}
 .nav nav{margin-left:0}
 table.packages{font-size:.9rem}
}
"""

JS_FILTER = """
<script>
(function(){
  var q=document.getElementById('q'), cards=[].slice.call(document.querySelectorAll('#toolGrid [data-search]'));
  var priceBtns=[].slice.call(document.querySelectorAll('[data-price]'));
  var price='All';
  function apply(){
    var needle=(q?q.value:'').toLowerCase().trim();
    cards.forEach(function(c){
      var okText=!needle||c.getAttribute('data-search').toLowerCase().indexOf(needle)>-1;
      var okPrice=price==='All'||c.getAttribute('data-pricing')===price;
      c.classList.toggle('hidden',!(okText&&okPrice));
    });
    var n=document.getElementById('count');
    if(n){var vis=cards.filter(function(c){return !c.classList.contains('hidden')}).length;
      n.textContent=vis+' tool'+(vis===1?'':'s')+' shown';
      var nr=document.getElementById('noresults');
      if(nr){nr.hidden=vis!==0;}}
  }
  var clr=document.getElementById('clearFilters');
  if(clr){clr.addEventListener('click',function(){
    if(q){q.value='';}
    price='All';
    priceBtns.forEach(function(x){x.setAttribute('aria-pressed',x.getAttribute('data-price')==='All'?'true':'false')});
    apply(); if(q){q.focus();}});}
  if(q){q.addEventListener('input',apply);}
  priceBtns.forEach(function(b){b.addEventListener('click',function(){
    price=b.getAttribute('data-price');
    priceBtns.forEach(function(x){x.setAttribute('aria-pressed',x===b?'true':'false')});
    apply();});});
  apply();
})();
</script>
"""

LOGO_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" role="img" aria-label="MXY AI logo">
<rect x="2" y="2" width="60" height="60" rx="12" fill="#0C4A34"/>
<path d="M16 44 V20 l10 12 6-8 6 8 10-12 v24" fill="none" stroke="#F7F5F0" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
<circle cx="16" cy="20" r="3.4" fill="#E9B44C"/><circle cx="32" cy="24" r="3.4" fill="#E9B44C"/><circle cx="48" cy="20" r="3.4" fill="#E9B44C"/>
</svg>"""

def tool_logo_svg(t):
    ini = initials(t["name"]); color = t.get("_color", "#0C4A34")
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96" role="img" aria-label="{esc(t['name'])} placeholder logo">
<rect width="96" height="96" rx="18" fill="{color}"/>
<text x="48" y="60" font-family="Archivo, Arial, sans-serif" font-size="34" font-weight="800" fill="#F7F5F0" text-anchor="middle">{esc(ini)}</text>
<circle cx="76" cy="20" r="6" fill="#E9B44C"/>
</svg>"""

def png_bytes(w, h, pixel):
    raw = b""
    for y in range(h):
        raw += b"\x00" + b"".join(bytes(pixel(x, y)) for x in range(w))
    def chunk(typ, data):
        c = struct.pack(">I", len(data)) + typ + data
        return c + struct.pack(">I", zlib.crc32(typ + data) & 0xFFFFFFFF)
    ihdr = struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) +
            chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))

def make_og_png(path):
    pine = (12, 74, 52); amber = (233, 180, 76); paper = (247, 245, 240); dark = (7, 44, 32)
    def px(x, y):
        if y < 56 or y >= 574: return dark
        # amber node-grid M motif on the right side
        if 800 <= x < 1144 and 150 <= y < 480:
            gx, gy = (x - 800) // 86, (y - 150) // 82
            cx, cy = (x - 800) % 86, (y - 150) % 82
            if 26 < cx < 60 and 24 < cy < 58 and (gx + gy) % 2 == 0: return amber
        if 70 <= x < 760 and 250 <= y < 262: return amber
        return pine
    open(path, "wb").write(png_bytes(1200, 630, px))

def head(title, desc, path, extra=""):
    url = BASE + path
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{esc(title)}</title>
<meta name="description" content="{esc(desc)}">
<link rel="canonical" href="{url}">
<meta property="og:type" content="website">
<meta property="og:site_name" content="MXY AI">
<meta property="og:title" content="{esc(title)}">
<meta property="og:description" content="{esc(desc)}">
<meta property="og:url" content="{url}">
<meta property="og:image" content="{BASE}/og.png">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{esc(title)}">
<meta name="twitter:description" content="{esc(desc)}">
<meta name="twitter:image" content="{BASE}/og.png">
<link rel="icon" type="image/svg+xml" href="/favicon.svg">
<link rel="icon" type="image/png" href="/favicon.png">
<link rel="apple-touch-icon" href="/apple-touch-180.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@600;800&family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/style.css">
{extra}</head>
<body>
<a class="skip" href="#main">Skip to content</a>
"""

def header():
    return f"""<header class="site"><div class="wrap nav">
<a class="brand" href="/" aria-label="MXY AI home"><span style="display:inline-block;width:34px;height:34px">{LOGO_SVG}</span>MXY&nbsp;AI</a>
<nav aria-label="Main">
<a href="/categories/">Categories</a>
<a href="/featured/">Get Featured</a>
<a href="/guides/">Guides</a>
<a href="/about/">About</a>
<a href="/submit/" class="btn small amber">Submit a tool</a>
</nav></div></header>
<main id="main">
"""

FOOTER = """</main>
<footer class="site"><div class="wrap">
<div class="cols">
<div>
<p style="margin-top:0"><strong>MXY AI</strong> — Curated AI &amp; software tools by use case. A small, editorially curated directory: no paid rankings, no scraped dump.</p>
<p>Outbound links go to each tool’s official site. We do not currently earn commissions from them; if that ever changes, those links will be labeled and this note updated. Editorial scores are never sold.</p>
</div>
<nav aria-label="Footer">
<a href="/affiliate-disclosure/">Disclosure</a> ·
<a href="/privacy/">Privacy</a> ·
<a href="/terms/">Terms</a><br>
<a href="/categories/">Categories</a> ·
<a href="/featured/">Get Featured</a> ·
<a href="/submit/">Submit a tool</a> ·
<a href="/about/">About</a>
</nav>
</div>
<p class="small">© 2026 MXY AI. Tool names and trademarks belong to their owners; listings are editorial, not endorsements.</p>
</div></footer>
</body></html>"""

def card(t, top=False):
    cn = CAT[t["categories"][0]]["name"]
    feat = '<span class="badge feat">Editor’s pick</span>' if t["featured"] else ""
    return f"""<article class="card{' top' if top or t['featured'] else ''}" data-search="{esc(t['name'] + ' ' + ' '.join(t['tags']) + ' ' + cn)}" data-pricing="{esc(t['pricing'])}">
<div class="row"><img class="logo" src="{esc(t['logoUrl'])}" alt="{esc(t['name'])} logo placeholder" width="46" height="46" loading="lazy">
<h3><a href="/tool/{t['slug']}/">{esc(t['name'])}</a></h3></div>
<p>{esc(t['tagline'])}</p>
<div class="meta">{feat}<span class="badge price">{esc(t['pricing'])}</span>
<span class="score">Editorial score {t['editorialScore']}/5</span></div>
<p class="small" style="margin:0">{esc(cn)} · Best for: {esc(t['bestFor'])}</p>
<div class="actions"><a class="btn small" href="{esc(t['affiliateUrl'] or t['websiteUrl'])}" target="_blank" rel="{'sponsored nofollow noopener' if t['affiliateUrl'] else 'noopener'}">Visit site</a>
<a class="btn small ghost" href="/tool/{t['slug']}/">Details</a></div>
</article>"""

def page(path, title, desc, body, extra=""):
    out = os.path.join(DIST, path.lstrip("/"))
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "index.html"), "w") as f:
        f.write(head(title, desc, path if path.endswith("/") else path + "/", extra) + header() + body + FOOTER)
    return path if path.endswith("/") else path + "/"

# ---------- pages ----------
def home():
    cat_cards = "".join(
        f'<a class="catcard" href="/category/{c["slug"]}/"><h3>{esc(c["name"])}</h3>'
        f'<p>{esc(c["description"])}</p><p class="n">{sum(1 for t in tools if t["categories"][0]==c["slug"])} tools</p></a>'
        for c in cats)
    feat_cards = "".join(card(t, top=True) for t in FEATURED)
    latest = "".join(card(t) for t in LATEST[:8])
    all_cards = "".join(card(t) for t in sorted(tools, key=lambda x: (not x["featured"], -(x["editorialScore"]))))
    body = f"""<div class="hero"><div class="wrap">
<p class="kicker">A niche directory — 50 tools, 11 use cases</p>
<h1>AI &amp; software tools, <em>sorted by the job</em> you need done.</h1>
<p class="lede">MXY AI is a curated directory of AI and software tools organized by use case — writing, video, support, sales, and more. Every listing carries an original write-up — what it does, what it costs, and where it falls short — and a link to the official site. No scraped dump of ten thousand logos.</p>
<form class="searchbar" role="search" onsubmit="return false">
<label class="sr-only" for="q">Search tools</label>
<input id="q" type="search" placeholder="Search 50 tools — try “transcription”, “logo”, “crm”" autocomplete="off">
<a class="btn" href="#all-tools">Browse all</a>
</form>
<p class="small">Popular: <a href="/category/meeting-notes-transcription/">Meeting notes</a> · <a href="/category/ai-for-video/">AI for video</a> · <a href="/category/open-source-alternatives/">Open-source alternatives</a></p>
</div></div>
<div class="wrap">
<section class="block"><h2>Start with a use case</h2>
<p class="sub">Eleven narrow categories. Pick the job, then compare a short list — not a phone book.</p>
<div class="catgrid">{cat_cards}</div></section>
<section class="block"><h2>Editor’s picks</h2>
<p class="sub">Five listings given the Editor’s pick label. Picks are unpaid and never sold, and they are held to the same editorial standard as every listing — a pick never changes an editorial score.</p>
<div class="grid">{feat_cards}</div></section>
<section class="block" id="all-tools"><h2>All tools</h2>
<p class="sub" id="count"></p>
<div class="filters" role="group" aria-label="Filter by pricing">
<button type="button" data-price="All" aria-pressed="true">All pricing</button>
<button type="button" data-price="Free" aria-pressed="false">Free</button>
<button type="button" data-price="Freemium" aria-pressed="false">Freemium</button>
<button type="button" data-price="Paid" aria-pressed="false">Paid</button>
<button type="button" data-price="Enterprise" aria-pressed="false">Enterprise</button>
</div>
<div class="grid" id="toolGrid">{all_cards}</div>
<div id="noresults" class="noresults" hidden>
<p><strong>No tools match that search.</strong> Try a different keyword, or clear the search and the price filter to see the full directory again.</p>
<button type="button" class="btn ghost" id="clearFilters">Clear search &amp; filters</button>
</div></section>
<section class="block"><h2>Latest additions</h2>
<div class="grid">{latest}</div></section>
<div class="cta-band"><h2>Built a good tool? Get it in front of buyers.</h2>
<p>Basic listings are free, and paid or not, every listing is presented the same way — same format, same scoring. A paid Featured program is in the works — its planned packages are public on the Featured page, and anything paid will always be labeled as advertising.</p>
<a class="btn amber" href="/featured/">Get featured</a> <a class="btn ghost" style="color:#fff;border-color:#fff" href="/submit/">Submit a tool (free)</a></div>
</div>
{JS_FILTER}"""
    return page("/", "MXY AI — Curated AI & Software Tools by Use Case",
                "MXY AI is a curated directory of AI and software tools organized by use case: writing, video, design, coding, support, and more. Compare 50 curated tools.", body)

def categories_page():
    items = "".join(
        f'<a class="catcard" href="/category/{c["slug"]}/"><h3>{esc(c["name"])}</h3>'
        f'<p>{esc(c["description"])}</p><p class="n">{sum(1 for t in tools if t["categories"][0]==c["slug"])} curated tools</p></a>'
        for c in cats)
    body = f"""<div class="wrap"><section class="block">
<p class="kicker">Directory index</p><h1 style="font-size:2.1rem;margin:0 0 8px">All categories</h1>
<p class="sub">Eleven use cases, kept narrow on purpose. If a category cannot be described in one sentence, it does not belong here.</p>
<div class="catgrid">{items}</div></section></div>"""
    return page("/categories", "All Categories — MXY AI",
                "Browse all 11 use-case categories in the MXY AI directory: AI for writers, video, design, coding, marketing, sales, support, and more.", body)

def category_page(c):
    lst = [t for t in tools if t["categories"][0] == c["slug"]]
    lst.sort(key=lambda x: (not x["featured"], -(x["editorialScore"])))
    cards = "".join(card(t) for t in lst)
    ld = {"@context": "https://schema.org", "@type": "ItemList",
          "name": f"{c['name']} — MXY AI",
          "itemListElement": [{"@type": "ListItem", "position": i + 1,
                               "url": f"{BASE}/tool/{t['slug']}/", "name": t["name"]}
                              for i, t in enumerate(lst)]}
    extra = f'<script type="application/ld+json">{json.dumps(ld)}</script>\n'
    body = f"""<div class="wrap"><section class="block">
<p class="kicker">Category</p><h1 style="font-size:2.1rem;margin:0 0 8px">{esc(c['name'])}</h1>
<p class="sub">{esc(c['description'])} {len(lst)} tools, edited and ranked by our editorial score — editor’s picks are labeled and listed first; placement is never sold.</p>
<p class="small" id="count"></p>
<div class="filters" role="group" aria-label="Filter by pricing">
<button type="button" data-price="All" aria-pressed="true">All pricing</button>
<button type="button" data-price="Free" aria-pressed="false">Free</button>
<button type="button" data-price="Freemium" aria-pressed="false">Freemium</button>
<button type="button" data-price="Paid" aria-pressed="false">Paid</button>
<button type="button" data-price="Enterprise" aria-pressed="false">Enterprise</button>
</div>
<div class="grid" id="toolGrid">{cards}</div>
<div id="noresults" class="noresults" hidden>
<p><strong>No tools in this category match that filter.</strong> Clear the price filter to see everything in this category again.</p>
<button type="button" class="btn ghost" id="clearFilters">Clear filters</button>
</div>
<p class="small" style="margin-top:22px">Know a tool that belongs here? <a href="/submit/">Submit it</a> — basic listings are free; submissions open as soon as our contact mailbox is live.</p>
</section></div>
{JS_FILTER}"""
    return page(f"/category/{c['slug']}", f"{c['name']} — Best Tools, Curated | MXY AI",
                f"{c['description']} Compare {len(lst)} curated picks with honest editorial scores, pricing, and pros and cons.", body, extra)

def tool_page(t):
    c = CAT[t["categories"][0]]
    related = [x for x in tools if x["categories"][0] == c["slug"] and x["slug"] != t["slug"]]
    related.sort(key=lambda x: -(x["editorialScore"]))
    rel_cards = "".join(card(x) for x in related[:3])
    pros = "".join(f"<li>{esc(p)}</li>" for p in t["pros"])
    cons = "".join(f"<li>{esc(p)}</li>" for p in t["cons"])
    plats = ", ".join(t["platforms"])
    tags = " · ".join(esc(x) for x in t["tags"])
    feat = '<span class="badge feat">Editor’s pick</span>' if t["featured"] else ""
    ld = {"@context": "https://schema.org", "@type": "SoftwareApplication",
          "name": t["name"], "description": t["description"],
          "applicationCategory": "BusinessApplication", "operatingSystem": plats,
          "url": t["websiteUrl"],
          "aggregateRating": None}
    ld = {k: v for k, v in ld.items() if v is not None}
    if t["pricing"] == "Free":
        ld["offers"] = {"@type": "Offer", "price": "0", "priceCurrency": "USD"}
    extra = f'<script type="application/ld+json">{json.dumps(ld)}</script>\n'
    body = f"""<div class="wrap"><section class="block">
<p class="kicker"><a href="/category/{c['slug']}/">{esc(c['name'])}</a></p>
<div class="row" style="display:flex;gap:16px;align-items:center;flex-wrap:wrap">
<img src="{esc(t['logoUrl'])}" alt="{esc(t['name'])} logo placeholder" width="72" height="72" style="border-radius:14px">
<h1 style="font-size:2.2rem;margin:0">{esc(t['name'])}</h1>{feat}</div>
<p class="lede" style="font-size:1.12rem;color:#33413A;max-width:44em">{esc(t['tagline'])}</p>
<p style="max-width:46em">{esc(t['description'])}</p>
<div class="meta" style="margin:14px 0">
<span class="badge price">{esc(t['pricing'])}</span>
<span class="score">Editorial score {t['editorialScore']}/5</span>
<span class="small">Platforms: {esc(plats)}</span>
<span class="small">Listed {esc(t['dateAdded'])}</span></div>
<p><a class="btn" href="{esc(t['affiliateUrl'] or t['websiteUrl'])}" target="_blank" rel="{'sponsored nofollow noopener' if t['affiliateUrl'] else 'noopener'}">Visit {esc(t['name'])}</a>
<a class="btn ghost" href="/category/{c['slug']}/">More {esc(c['name'].lower())} tools</a></p>
<p class="small">Outbound link to the vendor's site. See our <a href="/affiliate-disclosure/">disclosure</a>.</p>
<div class="proscons" style="margin-top:22px">
<div class="box"><h3 style="margin:0">What it does well</h3><ul>{pros}</ul></div>
<div class="box"><h3 style="margin:0">Worth knowing</h3><ul>{cons}</ul></div>
</div>
<p style="margin-top:20px"><strong>Best for:</strong> {esc(t['bestFor'])}</p>
<p class="small">Tags: {tags}</p>
</section>
<section class="block"><h2>Related in {esc(c['name'])}</h2>
<div class="grid">{rel_cards}</div></section></div>"""
    return page(f"/tool/{t['slug']}", f"{t['name']} — Review, Pricing & Alternatives | MXY AI",
                f"{t['name']}: {t['tagline']} Editorial score {t['editorialScore']}/5, {t['pricing'].lower()} pricing, honest pros and cons on MXY AI.", body, extra)

PACKAGES = [
 ("Starter Listing", "$49 / month", "Featured badge in one category, standard placement boost, listing copy review by an editor."),
 ("Category Spotlight", "$149 / month", "Top-of-category placement, homepage rotation for two weeks, badge, and a short editorial write-up."),
 ("Homepage Partner", "$399 / month", "Everything in Spotlight plus homepage featured section, guide mentions where genuinely relevant, and a quarterly performance summary."),
]

def featured_page():
    rows = "".join(f"<tr><th scope='row'>{esc(n)}</th><td>{esc(p)}</td><td>{esc(d)}</td></tr>" for n, p, d in PACKAGES)
    body = f"""<div class="wrap"><section class="block">
<p class="kicker">For tool makers</p><h1 style="font-size:2.1rem;margin:0 0 8px">Get featured on MXY AI</h1>
<p class="sub">Paid Featured placement is not open yet — no tool has paid for placement on MXY AI, and the Editor’s pick badges on the site today are unpaid. This page publishes the planned packages now so pricing is public before anything goes on sale.</p>
<div class="two">
<div><h2>What featured will include</h2>
<ul>
<li><strong>Top placement</strong> in your category, above organic listings</li>
<li><strong>Featured badge</strong> on every card and your tool page</li>
<li><strong>Homepage rotation</strong> in the Featured tools section (Spotlight and up)</li>
<li><strong>Editorial review</strong> — a person checks your listing copy, screenshots, and claims</li>
</ul>
<p>What it never includes: a better editorial score, fake reviews, or removal of honest cons. If we would not list it free, we will not feature it for pay.</p></div>
<div><h2>Packages</h2>
<table class="packages"><thead><tr><th scope="col">Package</th><th scope="col">Price</th><th scope="col">Includes</th></tr></thead>
<tbody>{rows}</tbody></table>
<p class="small">Planned launch pricing — not yet on sale, and no charge happens through this page. When the program opens, this page will say so and an inquiry form will appear here.</p></div>
</div>
<h2 style="margin-top:34px">Register interest in featured placement</h2>
<div class="box">
<p style="margin-top:0"><strong>Inquiries are not open yet.</strong> The contact mailbox for this program has not been set up, so this page cannot take your details today — there is deliberately no working form here, rather than one that goes nowhere. When the program opens, the inquiry form will appear on this page.</p>
<p class="small" style="margin-bottom:0">Until then, everything about the planned program — packages, rules, and the no-paid-scores policy — is published above and in our <a href="/affiliate-disclosure/">disclosure</a>.</p>
</div>
</section></div>"""
    return page("/featured", "Get Featured — MXY AI",
                "Planned Featured placement packages for MXY AI — published ahead of launch, labeled if paid, never tied to editorial scores.", body)

def submit_page():
    opts = "".join(f'<option value="{c["slug"]}">{esc(c["name"])}</option>' for c in cats)
    body = f"""<div class="wrap"><section class="block">
<p class="kicker">For tool makers</p><h1 style="font-size:2.1rem;margin:0 0 8px">Submit a tool</h1>
<p class="sub">Basic listings are free, and submitting will never guarantee one. When submissions open, each one is checked against a single test: does the tool do one job in one of our categories genuinely well?</p>
<div class="box">
<p style="margin-top:0"><strong>Submissions are not open yet.</strong> Our contact mailbox has not been set up, so there is deliberately no working form on this page — a form that sends your details nowhere helps nobody. When submissions open, the form will appear here.</p>
<p class="small" style="margin-bottom:0">Placement instead of a basic listing? See <a href="/featured/">Get Featured</a> — that program is not open yet either, and its page says so.</p>
</div>
</section></div>"""
    return page("/submit", "Submit a Tool — MXY AI",
                "Submit your AI or software tool to MXY AI for a free, human-reviewed basic listing in one of 11 use-case categories.", body)

def about_page():
    body = """<div class="wrap"><section class="block">
<p class="kicker">About</p><h1 style="font-size:2.1rem;margin:0 0 8px">A directory with an editor, not a scraper</h1>
<article class="guide">
<p>MXY AI exists because finding software got worse, not better. Search results are ads and listicles; app stores reward whoever games the ranking. We keep the opposite setup: a short list, organized by the job you need done, where every entry is written to the same standard — what the tool does, what it costs, and where it falls short.</p>
<h2>How we curate</h2>
<p>Each listing starts with a simple question — what job does this tool do, and for whom? Tools earn their place by doing that job well, not by paying. Descriptions are written for this directory, and each one names the trade-offs in plain language: credit limits, seat minimums, export locks, the things vendor pages put in the fine print.</p>
<h2>Editorial scores</h2>
<p>Scores run 1–5 and reflect our judgment of quality for the stated use case: reliability, depth, and value for the audience named on the page. They are opinions, labeled as ours. A paid Featured program is planned; it will be labeled as advertising and will never move a score. Today’s editor’s picks are unpaid.</p>
<h2>How we make money</h2>
<p>At the moment, neither: MXY AI currently earns nothing from its listings — no affiliate commissions and no paid placements. When the Featured program opens, placements will be labeled as advertising. See the full <a href="/affiliate-disclosure/">affiliate disclosure</a>.</p>
<h2>Corrections</h2>
<p>Tools change fast, and every listing shows the date it was added. A corrections channel will be published on the <a href="/submit/">submit page</a> when submissions open; until then, treat the vendor's own site as the final word on pricing and features.</p>
"""
    if os.path.isfile(os.path.join(DIST, "video", "promo-30s.mp4")):
        body += """<h2>Watch: the 30-second version</h2>
<p><video controls preload="none" poster="/video/thumbnail.png" width="360" style="max-width:100%;border-radius:12px" src="/video/promo-30s.mp4"></video></p>
"""
    body += "</article></section></div>"
    return page("/about", "About MXY AI — How We Curate",
                "MXY AI is a curated directory of AI and software tools by use case. How we curate, how editorial scores work, and how we make money.", body)

GUIDES = [
 {
  "slug": "how-to-pick-an-ai-writing-tool",
  "title": "How to Pick an AI Writing Tool Without Wasting a Month",
  "desc": "A practical way to choose an AI writing tool: start from the job, test on your own drafts, and check brand voice, editing depth, and total cost before you commit.",
  "date": "2026-10-20",
  "body": """
<p>Most teams pick an AI writing tool the wrong way: they read a listicle, try the flashiest demo, and discover a month later that nobody on the team actually opens it. The tool was never the problem — the selection process was. Here is the one we recommend to readers.</p>
<h2>Start from the job, not the model</h2>
<p>Write down the three writing jobs you do every week. Not "content" — specific jobs: first drafts of blog posts, ad copy variants, product descriptions, release notes. A tool that is excellent at short ad variants, like <a href="/tool/copy-ai/">Copy.ai</a>, may be mediocre at long drafts; a fiction tool like <a href="/tool/sudowrite/">Sudowrite</a> is wrong for marketing entirely. Our <a href="/category/ai-for-writers/">AI for Writers</a> category is organized around exactly this distinction.</p>
<h2>Test on your own drafts</h2>
<p>Give each candidate the same three real assignments from last month, including one you were unhappy with. Judge the output by editing time saved, not by how impressive the first paragraph looks. Every AI writer produces a confident first paragraph. The difference shows up in paragraph nine, where structure, facts, and voice either hold or quietly fall apart.</p>
<h2>Check brand voice controls</h2>
<p>If more than one person will publish with the tool, voice consistency matters more than raw quality. This is where <a href="/tool/jasper/">Jasper</a> earns its price for marketing teams: briefs and voice settings keep ten writers sounding like one brand. Solo writers can usually skip this layer — a calm editor like <a href="/tool/lex/">Lex</a> plus your own judgment is often the better buy.</p>
<h2>Price the whole workflow</h2>
<p>Compare total cost, not the sticker. Seat minimums, word credits, SEO add-ons, and the tier you actually need (not the teaser tier) decide the real number. Freemium tools like <a href="/tool/writesonic/">Writesonic</a> are a sensible way to validate the habit before paying for a platform.</p>
<h2>A simple decision rule</h2>
<p>If a tool saves one person two hours a week after editing, it is worth paying for. If it produces drafts nobody wants to edit, it is expensive at any price. Run the two-week test, measure honestly, and let your own drafts — not a demo — make the call.</p>
""",
 },
 {
  "slug": "ai-meeting-notes-what-actually-matters",
  "title": "AI Meeting Notes: What Actually Matters After the Call",
  "desc": "Transcription accuracy is table stakes. What separates good AI notetakers is what happens after the call: summaries people trust, searchable history, and where the notes go next.",
  "date": "2026-10-27",
  "body": """
<p>Every AI notetaker can transcribe a clear call reasonably well in 2026. Accuracy still matters, but it is no longer the deciding factor. The tools diverge on what happens in the hour after the meeting — and on whether your team keeps using them in month three.</p>
<h2>Summaries people actually trust</h2>
<p>A useful summary is short, names decisions and owners, and links claims back to the transcript. <a href="/tool/otter-ai/">Otter.ai</a> and <a href="/tool/fathom/">Fathom</a> both structure summaries around action items rather than dumping a wall of text. Read three summaries from real calls before choosing; if you cannot tell who owes what by Friday, the summary failed.</p>
<h2>Bot or no bot</h2>
<p>Bot-based tools join the call as a visible participant. That transparency is good practice, but it changes the room — clients get cautious, candidates get formal. <a href="/tool/granola/">Granola</a> takes the other route, capturing audio from your own device and folding your rough notes into the summary. Decide as a team which trade-off fits your meetings, and set a consent norm either way.</p>
<h2>Where the notes go next</h2>
<p>Notes trapped in the notetaker's app decay fast. If your calls should update the CRM, look at <a href="/tool/fireflies-ai/">Fireflies.ai</a>, which pushes highlights and transcripts into HubSpot, Slack, and similar tools. The best archive is the one your team already searches.</p>
<h2>Search across meetings</h2>
<p>The quiet superpower of this category is a searchable history: "What did the client say about pricing in September?" should take seconds. All four tools in our <a href="/category/meeting-notes-transcription/">Meeting Notes &amp; Transcription</a> category do this, but depth of search — speakers, topics, action items — varies enough to test with your own past calls.</p>
<h2>Price reality check</h2>
<p>Fathom made its core notetaker free, which reset expectations for the whole category. Pay for team analytics, CRM automation, and admin controls when you need them — not for basic recording your team could get free.</p>
""",
 },
]

def guides_index():
    items = "".join(
        f'<article class="card"><h3><a href="/guides/{g["slug"]}/">{esc(g["title"])}</a></h3>'
        f'<p>{esc(g["desc"])}</p><p class="small">Published {g["date"]}</p>'
        f'<div class="actions"><a class="btn small ghost" href="/guides/{g["slug"]}/">Read guide</a></div></article>'
        for g in GUIDES)
    body = f"""<div class="wrap"><section class="block">
<p class="kicker">Guides</p><h1 style="font-size:2.1rem;margin:0 0 8px">Guides</h1>
<p class="sub">Short, practical reading on choosing tools — written from the same editorial desk as the directory. No listicles we would not sign.</p>
<div class="grid">{items}</div></section></div>"""
    return page("/guides", "Guides — MXY AI",
                "Practical guides on choosing AI and software tools, from the MXY AI editors: writing tools, meeting notes, and more.", body)

def guide_page(g):
    body = g["body"]
    out = f"""<div class="wrap"><section class="block">
<p class="kicker"><a href="/guides/">Guides</a></p>
<h1 style="font-size:2rem;margin:0 0 8px;max-width:22em">{esc(g['title'])}</h1>
<p class="small">Published {g['date']} · MXY AI editors</p>
<article class="guide">{body}</article>
<div class="cta-band"><h2>Browse the directory</h2>
<p>Every tool mentioned here is listed with honest pros, cons, and an editorial score.</p>
<a class="btn amber" href="/categories/">Explore categories</a></div>
</section></div>"""
    return page(f"/guides/{g['slug']}", f"{g['title']} | MXY AI Guides", g["desc"], out)

def legal_page(path, title, desc, heading, paras):
    content = "".join(f"<p>{p}</p>" if not p.startswith("<h2>") else p for p in paras)
    body = f"""<div class="wrap"><section class="block">
<h1 style="font-size:2rem;margin:0 0 12px">{esc(heading)}</h1>
<article class="guide">{content}</article>
<p class="small">Last updated: {TODAY}. This page is a plain-language summary of our practices, not legal advice; have counsel review before relying on it.</p>
</section></div>"""
    return page(path, title, desc, body)

def build():
    if os.path.isdir(DIST):
        shutil.rmtree(DIST)
    os.makedirs(os.path.join(DIST, "assets"))
    os.makedirs(os.path.join(DIST, "images", "tools"))
    with open(os.path.join(DIST, "assets", "style.css"), "w") as f: f.write(CSS)
    with open(os.path.join(DIST, "favicon.svg"), "w") as f: f.write(LOGO_SVG)
    open(os.path.join(DIST, "favicon.png"), "wb").write(
        png_bytes(64, 64, lambda x, y: (12, 74, 52) if not (26 < x < 38 and 26 < y < 38) else (233, 180, 76)))
    open(os.path.join(DIST, "apple-touch-180.png"), "wb").write(
        png_bytes(180, 180, lambda x, y: (12, 74, 52) if not (73 < x < 107 and 73 < y < 107) else (233, 180, 76)))
    make_og_png(os.path.join(DIST, "og.png"))
    # --- HQ integration: canonical brand assets + promo video override placeholders when present ---
    _brand = os.path.join(ROOT, "..", "..", "images", "brand", "mxyai88")
    def _cpy(src, dst):
        if os.path.isfile(src):
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copyfile(src, dst)
    _cpy(os.path.join(_brand, "og-default.png"), os.path.join(DIST, "og.png"))
    _cpy(os.path.join(_brand, "favicon-32.png"), os.path.join(DIST, "favicon.png"))
    _cpy(os.path.join(_brand, "apple-touch-180.png"), os.path.join(DIST, "apple-touch-180.png"))
    _cpy(os.path.join(_brand, "logo-mark.svg"), os.path.join(DIST, "logo-mark.svg"))
    _cpy(os.path.join(_brand, "logo-lockup.svg"), os.path.join(DIST, "logo-lockup.svg"))
    _cpy(os.path.join(_brand, "logo-on-dark.svg"), os.path.join(DIST, "logo-on-dark.svg"))
    _vdir = os.path.join(ROOT, "..", "..", "videos", "mxyai88")
    _cpy(os.path.join(_vdir, "promo-30s.mp4"), os.path.join(DIST, "video", "promo-30s.mp4"))
    _cpy(os.path.join(_vdir, "thumbnail.png"), os.path.join(DIST, "video", "thumbnail.png"))
    for t in tools:
        with open(os.path.join(DIST, "images", "tools", t["slug"] + ".svg"), "w") as f:
            f.write(tool_logo_svg(t))

    routes = []
    routes.append(home())
    routes.append(categories_page())
    for c in cats: routes.append(category_page(c))
    for t in tools: routes.append(tool_page(t))
    routes.append(featured_page())
    routes.append(submit_page())
    routes.append(about_page())
    routes.append(guides_index())
    for g in GUIDES: routes.append(guide_page(g))
    routes.append(legal_page("/affiliate-disclosure", "Affiliate Disclosure — MXY AI",
        "How MXY AI plans to make money — and the current state: no affiliate commissions and no paid placements.",
        "Affiliate Disclosure", [
        "This page states, plainly and in line with the FTC's endorsement guidelines, how MXY AI does and does not make money.",
        "<h2>Featured listings</h2>",
        "Paid Featured placement is described on our <a href=\"/featured/\">Get Featured</a> page. The program is not open yet and no tool has paid for placement; the Editor’s pick badges on the site today are unpaid editorial selections. When paid placement opens, it will be labeled as advertising everywhere it appears, and payment will buy placement only — never a higher editorial score, never removal of honest downsides, and never coverage of a tool we would not list for free.",
        "<h2>Affiliate links</h2>",
        "MXY AI does not currently participate in any affiliate program, and no outbound link on this site earns us a commission. Visit buttons link to the tools’ official websites. If we join an affiliate program in the future, affected links will carry rel=\"sponsored\" and this page will be updated before those links go live.",
        "<h2>Editorial independence</h2>",
        "Editorial scores are our own judgment, assigned before any commercial relationship is considered. We do not accept payment to write, change, or remove a review, and we do not publish sponsored articles disguised as editorial content.",
        ]))
    routes.append(legal_page("/privacy", "Privacy Policy — MXY AI",
        "What MXY AI collects, what it does not, and the choices you have.",
        "Privacy Policy", [
        "MXY AI is a static directory site. We keep data collection deliberately small.",
        "<h2>What we collect</h2>",
        "If you email us or send a form inquiry, we receive the details you provide (name, email, tool URL, message) and use them only to respond. Our hosting and analytics providers may process standard server logs, including IP address and browser type, to operate and secure the site.",
        "<h2>What we do not do</h2>",
        "We do not sell personal information. We do not operate user accounts on this site, and we do not run third-party advertising trackers at launch. Outbound links lead to vendor sites governed by their own privacy policies.",
        "<h2>Cookies</h2>",
        "The site works without cookies for reading. If analytics or embedded services that set cookies are added later, this policy will be updated and, where required, a consent prompt will be shown before they load.",
        "<h2>Your choices</h2>",
        "You can ask us what information we hold about you from your emails to us, and ask for its deletion. We respond within a reasonable time.",
        ]))
    routes.append(legal_page("/terms", "Terms of Use — MXY AI",
        "The terms that govern use of the MXY AI directory.",
        "Terms of Use", [
        "By using MXY AI you agree to these terms. If you do not agree, please do not use the site.",
        "<h2>Editorial content</h2>",
        "Listings, scores, and guides are editorial opinions offered for general information. Software changes quickly; we work to keep listings accurate but cannot guarantee that prices, features, or availability shown here match a vendor's current offering. The vendor's own site is authoritative.",
        "<h2>Listings and submissions</h2>",
        "Submitting a tool does not guarantee a listing. We may edit listing copy for accuracy and clarity. If a paid Featured placement service is offered in the future, it will be labeled as advertising, and any placement may be declined or removed if a listing no longer meets our standards, with any prepaid, unused period refunded.",
        "<h2>Trademarks</h2>",
        "Tool names, logos, and trademarks belong to their respective owners. Their appearance here is editorial and does not imply endorsement by either party.",
        "<h2>Liability</h2>",
        "To the extent permitted by law, MXY AI is not liable for decisions made based on directory content. Test tools — especially with your own data — before relying on them in production.",
        ]))

    _nf_body = """<div class="wrap"><section class="block">
<p class="kicker">404</p><h1 style="font-size:2.1rem;margin:0 0 8px">That page is not in the directory</h1>
<p class="sub">The link may be wrong, or the page may have moved. Start from a use case instead:</p>
<p><a class="btn" href="/categories/">Browse categories</a> <a class="btn ghost" href="/">Back to home</a></p>
</section></div>"""
    with open(os.path.join(DIST, "404.html"), "w") as f:
        f.write(head("Page Not Found — MXY AI", "That page is not in the MXY AI directory. Browse AI and software tools by use case instead.", "/404", "") + header() + _nf_body + FOOTER)

    with open(os.path.join(DIST, "robots.txt"), "w") as f:
        f.write(f"User-agent: *\nAllow: /\n\nSitemap: {BASE}/sitemap.xml\n")
    with open(os.path.join(DIST, "sitemap.xml"), "w") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n')
        for r in sorted(set(routes)):
            f.write(f"  <url><loc>{BASE}{r}</loc><lastmod>{TODAY}</lastmod></url>\n")
        f.write("</urlset>\n")
    print(f"Built {len(set(routes))} routes, {len(tools)} tools, {len(FEATURED)} featured -> {DIST}")

if __name__ == "__main__":
    build()
